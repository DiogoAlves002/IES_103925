package b.ex2_3.IES.lab23web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab23webApplicationTests {

	@Test
	void contextLoads() {
	}

}
