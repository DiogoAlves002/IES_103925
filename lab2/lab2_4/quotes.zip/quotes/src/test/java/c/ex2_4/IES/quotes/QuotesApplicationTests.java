package c.ex2_4.IES.quotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
